package com.banking.app.mapper;

import com.banking.app.model.Bank;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BanksMapper {

    @Select("SELECT * FROM banks")
    List<Bank> findAll();

    @Select("SELECT * FROM banks WHERE id = #{id}")
    Bank findById(int id);

    @Insert("INSERT INTO banks(id, name) VALUES (#{id}, #{name})")
    @SelectKey(statement = "SELECT LAST_INSERT_ID()", keyProperty = "id", before = false, resultType = Integer.class)
    int addBank(Bank bank);

    @Delete("DELETE FROM banks WHERE id=#{id}")
    int deleteById(int id);
}
