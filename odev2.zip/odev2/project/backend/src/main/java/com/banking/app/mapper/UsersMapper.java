package com.banking.app.mapper;

import com.banking.app.model.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UsersMapper {

    @Select("SELECT * FROM users")
    List<User> findAll();

    @Select("SELECT * FROM users WHERE id = #{id}")
    User findById(int id);

    @Insert("INSERT INTO users(id, username, email, password, enabled, authorities) VALUES(#{id}, #{username}, #{email}, #{password}, #{enabled}, #{authorities})")
    void saveUser(User user);

    @Update("UPDATE users SET enabled=#{enabled} WHERE id=#{id}")
    void updateUser(User user);

    @Delete("DELETE FROM users WHERE id = #{id}")
    void deleteById(int id);

}
