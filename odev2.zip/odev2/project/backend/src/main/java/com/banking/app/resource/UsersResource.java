package com.banking.app.resource;

import com.banking.app.mapper.UsersMapper;
import com.banking.app.model.User;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/rest/users")
public class UsersResource {

    private UsersMapper usersMapper;

    public UsersResource(UsersMapper usersMapper) {
        this.usersMapper = usersMapper;
    }

    @GetMapping("/get")
    List<User> getAll() {
        return usersMapper.findAll();
    }

    @GetMapping("/get/{id}")
    User getUser(@PathVariable int id) {
        return usersMapper.findById(id);
    }

    @PostMapping("/add")
    ResponseEntity addUser(@RequestBody User user) {
        user.setAuthorities("CREATE_ACCOUNT");
        usersMapper.saveUser(user);
        return ResponseEntity.ok("ADDED");
    }

    @PutMapping("/activate/{id}")
    ResponseEntity activateUser(@PathVariable int id) {
        User x = usersMapper.findById(id);
        x.setEnabled(true);
        usersMapper.updateUser(x);
        return ResponseEntity.ok("UPDATED");
    }

    @PutMapping("/deactivate/{id}")
    ResponseEntity deactivateUser(@PathVariable int id) {
        User x = usersMapper.findById(id);
        x.setEnabled(false);
        usersMapper.updateUser(x);
        return ResponseEntity.ok("UPDATED");
    }

    @DeleteMapping("/delete/{id}")
    ResponseEntity deleteUser(@PathVariable int id) {
        usersMapper.deleteById(id);
        return ResponseEntity.ok("DELETED");
    }
}
