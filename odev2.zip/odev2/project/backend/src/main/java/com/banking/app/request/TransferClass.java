package com.banking.app.request;

public class TransferClass {

    private int sendID;
    private int getID;
    private double price;

    // SETTERS & GETTERS
    public int getSendID() {
        return sendID;
    }

    public void setSendID(int sendID) {
        this.sendID = sendID;
    }

    public int getGetID() {
        return getID;
    }

    public void setGetID(int getID) {
        this.getID = getID;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
