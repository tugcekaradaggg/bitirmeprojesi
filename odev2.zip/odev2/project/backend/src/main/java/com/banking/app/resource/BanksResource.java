package com.banking.app.resource;

import com.banking.app.mapper.BanksMapper;
import com.banking.app.model.Bank;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rest/banks")
public class BanksResource {

    private BanksMapper banksMapper;

    public BanksResource(BanksMapper banksMapper) {
        this.banksMapper = banksMapper;
    }

    @GetMapping("/get")
    public List<Bank> getAll() {
        return banksMapper.findAll();
    }

    @GetMapping("/get/{id}")
    public Bank getBank(@PathVariable int id) {
        return banksMapper.findById(id);
    }

    @PostMapping("/add")
    public ResponseEntity saveBank(@RequestBody Bank bank) {

        banksMapper.addBank(bank);
        return ResponseEntity.ok(HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteBank(@PathVariable int id) {
        banksMapper.deleteById(id);
        return ResponseEntity.ok("DELETED");
    }
}
