package com.banking.app.mapper;

import com.banking.app.model.Account;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface AccountsMapper {

    @Select("SELECT * FROM account")
    List<Account> findAll();

    @Select("SELECT * FROM account WHERE id = #{id}")
    Account findById(int id);

    @Delete("DELETE FROM account WHERE id = #{id}")
    int deleteById(int id);

    @Update("UPDATE account SET balance=${balance}, last_update_date = #{last_update_date} WHERE id = #{id}")
    void updateBalance(Account account);

}
