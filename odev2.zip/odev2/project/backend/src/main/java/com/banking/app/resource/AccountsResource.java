package com.banking.app.resource;

import com.banking.app.mapper.AccountsMapper;
import com.banking.app.model.Account;
import com.banking.app.request.DepositClass;
import com.banking.app.request.TransferClass;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/rest/accounts")
public class AccountsResource {
    private AccountsMapper accountsMapper;

    public AccountsResource(AccountsMapper accountsMapper) {
        this.accountsMapper = accountsMapper;
    }

    @GetMapping("/get")
    public List<Account> getAll() {
        return accountsMapper.findAll();
    }

    @GetMapping("/get/{id}")
    public Account getUser(@PathVariable int id) {
        return accountsMapper.findById(id);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteUser(@PathVariable int id) {
        accountsMapper.deleteById(id);
        return ResponseEntity.ok("DELETED");
    }

    @PutMapping("/transfer")
    public ResponseEntity transferMoney(@RequestBody TransferClass transferClass) {
        System.out.println(transferClass.getSendID() + " " + transferClass.getGetID());
        Account sendAccount = accountsMapper.findById(transferClass.getSendID());
        Account getAccount = accountsMapper.findById(transferClass.getGetID());

        if(sendAccount != null && getAccount != null) {
            if(sendAccount.getBalance() < transferClass.getPrice()) {
                return ResponseEntity.status(404).body("BALANCE IS NOT ENOUGH");
            }else {
                // Update send user
                sendAccount.setBalance(sendAccount.getBalance() - transferClass.getPrice());
                sendAccount.setLast_update_date(new Date().toString());
                accountsMapper.updateBalance(sendAccount);
                // Update get user
                getAccount.setBalance(getAccount.getBalance() + transferClass.getPrice());
                sendAccount.setLast_update_date(new Date().toString());
                accountsMapper.updateBalance(getAccount);
                return ResponseEntity.ok("TRANSFERRED");
            }
        }else {

            return ResponseEntity.ok("NOT TRANSFERRED");
        }
    }

    @PutMapping("/depositMoney")
    public ResponseEntity depositMoney(@RequestBody DepositClass depositClass) {
        Account acc = accountsMapper.findById(depositClass.getId());
        if(acc != null) {
            acc.setBalance(acc.getBalance() + depositClass.getBalance());
            accountsMapper.updateBalance(acc);
        }else {
            return ResponseEntity.status(404).body("There is no such an account");
        }
        return  ResponseEntity.ok("DEPOSITED");
    }

    @PutMapping("/withdrawMoney")
    public ResponseEntity withdrawMoney(@RequestBody DepositClass depositClass) {
        Account acc = accountsMapper.findById(depositClass.getId());

        if(acc != null) {
            if(acc.getBalance() < depositClass.getBalance()) {
                return ResponseEntity.status(404).body("THERE IS NOT ENOUGH BALANCE");
            }else {
                acc.setBalance(acc.getBalance() - depositClass.getBalance());
                accountsMapper.updateBalance(acc);
            }
        }else {
            return ResponseEntity.status(404).body("NO SUCH AN ACCOUNT");
        }

        return ResponseEntity.ok("WITHDRAWED");
    }

}
